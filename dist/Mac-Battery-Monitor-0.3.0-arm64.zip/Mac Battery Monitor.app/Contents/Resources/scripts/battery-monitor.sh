#!/bin/bash
# Compatible con el Bash del sistema. No cargar este archivo como root.

export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export LC_ALL=C
umask 077

validate_thresholds() {
    if [[ ! "$1" =~ ^[1-9][0-9]?$ || ! "$2" =~ ^[1-9][0-9]?$ ]]; then
        printf 'Los porcentajes deben ser enteros entre 1 y 99.\n' >&2
        return 1
    fi
}

load_settings() {
    local content version extra
    alert_threshold=30; power_threshold=20
    if [ -f "$data_dir/settings" ]; then
        content=$(/bin/cat "$data_dir/settings") || return 1
        if [[ "$content" == *$'\n'* ]]; then
            printf 'Configuración inválida: se esperaba una sola línea.\n' >&2; return 1
        fi
        IFS=' ' read -r version alert_threshold power_threshold extra <<< "$content"
        if [ "$version" != v1 ] || [ -n "$extra" ] || ! validate_thresholds "$alert_threshold" "$power_threshold"; then
            printf 'Configuración inválida: %s/settings\n' "$data_dir" >&2; return 1
        fi
    fi
    # La recarga debe superar ambos umbrales con margen; siempre se rearma al 100 %.
    rearm_level=$((alert_threshold > power_threshold ? alert_threshold + 6 : power_threshold + 6))
    [ "$rearm_level" -le 100 ] || rearm_level=100
}

save_settings() {
    local temp
    validate_thresholds "$1" "$2" || return 1
    temp=$(/usr/bin/mktemp "$data_dir/settings.XXXXXX") || return 1
    if ! printf 'v1 %s %s\n' "$1" "$2" > "$temp"; then
        /bin/rm -f "$temp"; return 1
    fi
    /bin/mv -f "$temp" "$data_dir/settings" || { /bin/rm -f "$temp"; return 1; }
}

read_battery() {
    local output line value
    output=$(/usr/bin/pmset -g batt 2>&1) || { printf '%s\n' "$output" >&2; return 1; }
    parse_battery "$output"
}

parse_battery() {
    local output=$1 line value
    case "$output" in
        *"Now drawing from 'Battery Power'"*) power=battery ;;
        *"Now drawing from 'AC Power'"*) power=ac ;;
        *) printf 'Fuente de alimentación desconocida\n' >&2; return 1 ;;
    esac
    # Solo batería interna: ignorar UPS y periféricos con porcentaje.
    line=$(printf '%s\n' "$output" | /usr/bin/awk '/-InternalBattery-[0-9]+/ {print; exit}')
    value=$(printf '%s\n' "$line" | /usr/bin/sed -nE 's/.*[[:space:]]([0-9]{1,3})%;.*/\1/p')
    case "$value" in ''|*[!0-9]*) printf 'No se pudo leer la batería interna\n' >&2; return 1 ;; esac
    percent=$((10#$value))
    [ "$percent" -le 100 ] || { printf 'Porcentaje fuera de rango\n' >&2; return 1; }
}

log() {
    local size index
    if [ -f "$log_file" ]; then
        size=$(/usr/bin/stat -f %z "$log_file") || return 1
        if [ "$size" -ge 262144 ]; then
            for index in 2 1; do
                if [ -f "$log_file.$index" ]; then
                    /bin/mv -f "$log_file.$index" "$log_file.$((index + 1))" || return 1
                fi
            done
            /bin/mv -f "$log_file" "$log_file.1" || return 1
        fi
    fi
    printf '%s %s\n' "$(/bin/date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" >> "$log_file"
}

load_state() {
    local version extra
    notified=0; low_done=0; next_notice=0; next_power=0
    state_alert=30; state_power=20
    [ -f "$state_file" ] || return 0
    IFS=' ' read -r version notified low_done next_notice next_power state_alert state_power extra < "$state_file" || return 1
    if [ "$version" = v1 ] && [ -z "$state_alert$state_power$extra" ]; then
        # Migrar sin repetir avisos ya completados con los valores originales.
        state_alert=30; state_power=20
    elif [ "$version" != v2 ] || ! validate_thresholds "$state_alert" "$state_power"; then
        printf 'Versión o umbrales de estado inválidos: %s\n' "$state_file" >&2; return 1
    fi
    if [[ ! "$notified" =~ ^[01]$ || ! "$low_done" =~ ^[01]$ ||
          ! "$next_notice" =~ ^[0-9]{1,11}$ || ! "$next_power" =~ ^[0-9]{1,11}$ || -n "$extra" ]]; then
        printf 'Estado inválido: %s. Revisarlo antes de eliminarlo.\n' "$state_file" >&2
        return 1
    fi
    # Forzar base decimal al leer datos persistidos.
    next_notice=$((10#$next_notice)); next_power=$((10#$next_power))
}

save_state() {
    local temp
    temp=$(/usr/bin/mktemp "$data_dir/state.XXXXXX") || return 1
    if ! printf 'v2 %s %s %s %s %s %s\n' "$notified" "$low_done" "$next_notice" "$next_power" "$state_alert" "$state_power" > "$temp"; then
        /bin/rm -f "$temp"; return 1
    fi
    /bin/mv -f "$temp" "$state_file" || { /bin/rm -f "$temp"; return 1; }
}

notify() {
    local native="$HOME/Library/Application Support/MacBatteryMonitor/Notifier.app/Contents/MacOS/MacBatteryMonitor"
    if [ -x "$native" ]; then
        "$native" --notify "$1"
        return $?
    fi
    /usr/bin/osascript - "$1" <<'APPLESCRIPT'
on run argv
    display notification (item 1 of argv) with title "Monitor de batería" sound name "Glass"
end run
APPLESCRIPT
}

low_power_value() {
    local output value
    output=$(/usr/bin/pmset -g custom 2>&1) || { printf '%s\n' "$output" >&2; return 1; }
    value=$(printf '%s\n' "$output" | /usr/bin/awk '
        /^[^ \t]/ { battery = ($0 ~ /^Battery Power:/) }
        battery && $1 == "lowpowermode" { print $2; exit }')
    case "$value" in 0|1) printf '%s\n' "$value" ;; *) printf 'lowpowermode no disponible para batería\n' >&2; return 1 ;; esac
}

enable_low_power() {
    # -n: nunca solicitar contraseña. -k: no usar credenciales temporales en caché.
    # Solo funciona si existe una autorización NOPASSWD para este comando exacto.
    /usr/bin/sudo -n -k /usr/bin/pmset -b lowpowermode 1
}

check_once() {
    local now current result
    now=$(/bin/date +%s) || return 1
    load_settings || { log 'ERROR configuración inválida; no se ejecutan acciones'; return 1; }
    load_state || { log 'ERROR estado persistente inválido'; return 1; }
    # Cambiar solo un umbral rearma únicamente su acción, no la otra.
    if [ "$state_alert" -ne "$alert_threshold" ] || [ "$state_power" -ne "$power_threshold" ]; then
        if [ "$state_alert" -ne "$alert_threshold" ]; then notified=0; next_notice=0; fi
        if [ "$state_power" -ne "$power_threshold" ]; then low_done=0; next_power=0; fi
        state_alert=$alert_threshold; state_power=$power_threshold
        save_state || return 1
        log "INFO umbrales actualizados: aviso=$alert_threshold% bajo_consumo=$power_threshold%" || return 1
    fi
    if ! read_battery; then log 'ERROR no se pudo consultar pmset'; return 1; fi
    log "INFO batería=$percent% fuente=$power" || return 1

    # Histéresis: enchufar con poca carga no habilita otro aviso.
    if [ "$percent" -ge "$rearm_level" ]; then
        notified=0; low_done=0; next_notice=0; next_power=0
        save_state || return 1
    fi
    [ "$power" = battery ] || return 0

    if [ "$percent" -le "$alert_threshold" ] && [ "$notified" -eq 0 ] && [ "$now" -ge "$next_notice" ]; then
        next_notice=$((now + 900))
        save_state || return 1
        if result=$(notify "Batería al $percent %. Conecta el cargador." 2>&1); then
            notified=1
            save_state || return 1
            log "INFO aviso enviado al sistema ($percent%)" || return 1
        else
            log "ERROR notificación: $result; reintento en 15 minutos" || return 1
        fi
    fi

    if [ "$percent" -le "$power_threshold" ] && [ "$low_done" -eq 0 ] && [ "$now" -ge "$next_power" ]; then
        next_power=$((now + 900))
        save_state || return 1
        if ! current=$(low_power_value 2>&1); then
            log "ERROR consulta de bajo consumo: $current; reintento en 15 minutos"
            return 1
        fi
        if [ "$current" = 1 ]; then
            low_done=1
            log 'INFO bajo consumo ya activo para batería' || return 1
        elif result=$(enable_low_power 2>&1); then
            if current=$(low_power_value 2>&1) && [ "$current" = 1 ]; then
                low_done=1
                log 'INFO bajo consumo activado y verificado para batería' || return 1
            else
                log "ERROR pmset terminó sin confirmar activación: $current" || return 1
            fi
        else
            log "ERROR activación no autorizada o fallida: $result; reintento en 15 minutos" || return 1
        fi
        save_state || return 1
    fi
}

main() {
    local mode=${1:---check} self status
    case "$mode" in --check|--locked|--dry-run|--test-notification|--show-settings|--configure|--configure-locked) ;; *)
        printf 'Uso: %s [--check|--dry-run|--test-notification|--show-settings|--configure AVISO AHORRO]\n' "$0" >&2; return 2 ;;
    esac
    case "$mode" in
        --configure|--configure-locked) [ "$#" -eq 3 ] || return 2; validate_thresholds "$2" "$3" || return 2 ;;
        *) [ "$#" -le 1 ] || return 2 ;;
    esac
    [ "$(/usr/bin/uname -s)" = Darwin ] || { printf 'Se requiere macOS\n' >&2; return 1; }
    [ "$EUID" -ne 0 ] || { printf 'Ejecuta el monitor como usuario, sin sudo\n' >&2; return 1; }
    data_dir="$HOME/Library/Application Support/MacBatteryMonitor"
    if [ "$mode" = --show-settings ]; then
        load_settings || return 1
        printf 'Aviso: %s%%; bajo consumo: %s%%; rearme: %s%%.\n' "$alert_threshold" "$power_threshold" "$rearm_level"
        return 0
    fi
    if [ "$mode" = --dry-run ]; then
        load_settings || return 1
        read_battery || return 1
        printf 'Batería: %s%%; fuente: %s. Aviso si <=%s%%; bajo consumo si <=%s%%.\n' "$percent" "$power" "$alert_threshold" "$power_threshold"
        printf 'Simulación: no se modifican estado, logs ni ajustes de energía.\n'
        return 0
    fi
    if [ "$mode" = --test-notification ]; then notify 'Prueba del monitor de batería.'; return $?; fi
    state_file="$data_dir/state"
    log_file="$HOME/Library/Logs/MacBatteryMonitor/monitor.log"
    /bin/mkdir -p "$data_dir" "${log_file%/*}" || return 1
    if [ "$mode" = --configure-locked ]; then
        save_settings "$2" "$3" || return 1
        log "INFO configuración guardada: aviso=$2% bajo_consumo=$3%" || return 1
        printf 'Porcentajes guardados. Se aplicarán en la próxima comprobación.\n'
        return 0
    fi
    if [ "$mode" != --locked ]; then
        self="$(cd -- "$(/usr/bin/dirname -- "$0")" && pwd)/$(/usr/bin/basename -- "$0")"
        if [ "$mode" = --configure ]; then
            /usr/bin/lockf -k -t 10 "$data_dir/check.lock" /bin/bash "$self" --configure-locked "$2" "$3"
            return $?
        fi
        /usr/bin/lockf -k -s -t 0 "$data_dir/check.lock" /bin/bash "$self" --locked
        status=$?
        # EX_TEMPFAIL significa que ya hay otra comprobación en curso.
        [ "$status" -ne 75 ] || return 0
        return "$status"
    fi
    if check_once 2>> "$log_file"; then
        return 0
    else
        log 'ERROR comprobación incompleta; revisar el registro y permisos de los archivos' || true
        return 1
    fi
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    set -u
    set -o pipefail
    main "$@"
fi
