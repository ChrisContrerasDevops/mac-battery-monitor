#!/bin/bash
# Compatible con el Bash del sistema. No cargar este archivo como root.

export PATH=/usr/bin:/bin:/usr/sbin:/sbin
export LC_ALL=C
umask 077

read_battery() {
    local output line value
    output=$(/usr/bin/pmset -g batt 2>&1) || { printf '%s\n' "$output" >&2; return 1; }
    parse_battery "$output"
}

parse_battery() {
    local output=$1 line value
    case "$output" in
        *"Now drawing from 'Battery Power'"*) power=battery ;;
        *"Now drawing from 'AC Power'"*) power=ac ;;
        *) printf 'Fuente de alimentación desconocida\n' >&2; return 1 ;;
    esac
    # Solo batería interna: ignorar UPS y periféricos con porcentaje.
    line=$(printf '%s\n' "$output" | /usr/bin/awk '/-InternalBattery-[0-9]+/ {print; exit}')
    value=$(printf '%s\n' "$line" | /usr/bin/sed -nE 's/.*[[:space:]]([0-9]{1,3})%;.*/\1/p')
    case "$value" in ''|*[!0-9]*) printf 'No se pudo leer la batería interna\n' >&2; return 1 ;; esac
    percent=$((10#$value))
    [ "$percent" -le 100 ] || { printf 'Porcentaje fuera de rango\n' >&2; return 1; }
}

log() {
    local size index
    if [ -f "$log_file" ]; then
        size=$(/usr/bin/stat -f %z "$log_file") || return 1
        if [ "$size" -ge 262144 ]; then
            for index in 2 1; do
                if [ -f "$log_file.$index" ]; then
                    /bin/mv -f "$log_file.$index" "$log_file.$((index + 1))" || return 1
                fi
            done
            /bin/mv -f "$log_file" "$log_file.1" || return 1
        fi
    fi
    printf '%s %s\n' "$(/bin/date -u '+%Y-%m-%dT%H:%M:%SZ')" "$*" >> "$log_file"
}

load_state() {
    local version extra
    notified=0; low_done=0; next_notice=0; next_power=0
    [ -f "$state_file" ] || return 0
    IFS=' ' read -r version notified low_done next_notice next_power extra < "$state_file" || return 1
    if [[ "$version" != v1 || ! "$notified" =~ ^[01]$ || ! "$low_done" =~ ^[01]$ ||
          ! "$next_notice" =~ ^[0-9]{1,11}$ || ! "$next_power" =~ ^[0-9]{1,11}$ || -n "$extra" ]]; then
        printf 'Estado inválido: %s. Revisarlo antes de eliminarlo.\n' "$state_file" >&2
        return 1
    fi
    # Forzar base decimal al leer datos persistidos.
    next_notice=$((10#$next_notice)); next_power=$((10#$next_power))
}

save_state() {
    local temp
    temp=$(/usr/bin/mktemp "$data_dir/state.XXXXXX") || return 1
    if ! printf 'v1 %s %s %s %s\n' "$notified" "$low_done" "$next_notice" "$next_power" > "$temp"; then
        /bin/rm -f "$temp"; return 1
    fi
    /bin/mv -f "$temp" "$state_file" || { /bin/rm -f "$temp"; return 1; }
}

notify() {
    local native="$HOME/Library/Application Support/MacBatteryMonitor/Notifier.app/Contents/MacOS/MacBatteryMonitor"
    if [ -x "$native" ]; then
        "$native" --notify "$1"
        return $?
    fi
    /usr/bin/osascript - "$1" <<'APPLESCRIPT'
on run argv
    display notification (item 1 of argv) with title "Monitor de batería" sound name "Glass"
end run
APPLESCRIPT
}

low_power_value() {
    local output value
    output=$(/usr/bin/pmset -g custom 2>&1) || { printf '%s\n' "$output" >&2; return 1; }
    value=$(printf '%s\n' "$output" | /usr/bin/awk '
        /^[^ \t]/ { battery = ($0 ~ /^Battery Power:/) }
        battery && $1 == "lowpowermode" { print $2; exit }')
    case "$value" in 0|1) printf '%s\n' "$value" ;; *) printf 'lowpowermode no disponible para batería\n' >&2; return 1 ;; esac
}

enable_low_power() {
    # -n: nunca solicitar contraseña. -k: no usar credenciales temporales en caché.
    # Solo funciona si existe una autorización NOPASSWD para este comando exacto.
    /usr/bin/sudo -n -k /usr/bin/pmset -b lowpowermode 1
}

check_once() {
    local now current result
    now=$(/bin/date +%s) || return 1
    load_state || { log 'ERROR estado persistente inválido'; return 1; }
    if ! read_battery; then log 'ERROR no se pudo consultar pmset'; return 1; fi
    log "INFO batería=$percent% fuente=$power" || return 1

    # Histéresis: enchufar con poca carga no habilita otro aviso.
    if [ "$percent" -gt 35 ]; then
        notified=0; low_done=0; next_notice=0; next_power=0
        save_state || return 1
    fi
    [ "$power" = battery ] || return 0

    if [ "$percent" -le 30 ] && [ "$notified" -eq 0 ] && [ "$now" -ge "$next_notice" ]; then
        next_notice=$((now + 900))
        save_state || return 1
        if result=$(notify "Batería al $percent %. Conecta el cargador." 2>&1); then
            notified=1
            save_state || return 1
            log "INFO aviso enviado al sistema ($percent%)" || return 1
        else
            log "ERROR notificación: $result; reintento en 15 minutos" || return 1
        fi
    fi

    if [ "$percent" -le 20 ] && [ "$low_done" -eq 0 ] && [ "$now" -ge "$next_power" ]; then
        next_power=$((now + 900))
        save_state || return 1
        if ! current=$(low_power_value 2>&1); then
            log "ERROR consulta de bajo consumo: $current; reintento en 15 minutos"
            return 1
        fi
        if [ "$current" = 1 ]; then
            low_done=1
            log 'INFO bajo consumo ya activo para batería' || return 1
        elif result=$(enable_low_power 2>&1); then
            if current=$(low_power_value 2>&1) && [ "$current" = 1 ]; then
                low_done=1
                log 'INFO bajo consumo activado y verificado para batería' || return 1
            else
                log "ERROR pmset terminó sin confirmar activación: $current" || return 1
            fi
        else
            log "ERROR activación no autorizada o fallida: $result; reintento en 15 minutos" || return 1
        fi
        save_state || return 1
    fi
}

main() {
    local mode=${1:---check} self status
    case "$mode" in --check|--locked|--dry-run|--test-notification) ;; *)
        printf 'Uso: %s [--check|--dry-run|--test-notification]\n' "$0" >&2; return 2 ;;
    esac
    [ "$#" -le 1 ] || return 2
    [ "$(/usr/bin/uname -s)" = Darwin ] || { printf 'Se requiere macOS\n' >&2; return 1; }
    [ "$EUID" -ne 0 ] || { printf 'Ejecuta el monitor como usuario, sin sudo\n' >&2; return 1; }
    if [ "$mode" = --dry-run ]; then
        read_battery || return 1
        printf 'Batería: %s%%; fuente: %s. Aviso si <=30%%; bajo consumo si <=20%%.\n' "$percent" "$power"
        printf 'Simulación: no se modifican estado, logs ni ajustes de energía.\n'
        return 0
    fi
    if [ "$mode" = --test-notification ]; then notify 'Prueba del monitor de batería.'; return $?; fi
    data_dir="$HOME/Library/Application Support/MacBatteryMonitor"
    state_file="$data_dir/state"
    log_file="$HOME/Library/Logs/MacBatteryMonitor/monitor.log"
    /bin/mkdir -p "$data_dir" "${log_file%/*}" || return 1
    if [ "$mode" != --locked ]; then
        self="$(cd -- "$(/usr/bin/dirname -- "$0")" && pwd)/$(/usr/bin/basename -- "$0")"
        /usr/bin/lockf -k -s -t 0 "$data_dir/check.lock" /bin/bash "$self" --locked
        status=$?
        # EX_TEMPFAIL significa que ya hay otra comprobación en curso.
        [ "$status" -ne 75 ] || return 0
        return "$status"
    fi
    if check_once 2>> "$log_file"; then
        return 0
    else
        log 'ERROR comprobación incompleta; revisar el registro y permisos de los archivos' || true
        return 1
    fi
}

if [ "${BASH_SOURCE[0]}" = "$0" ]; then
    set -u
    set -o pipefail
    main "$@"
fi
